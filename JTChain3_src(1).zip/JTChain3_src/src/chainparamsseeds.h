#ifndef CHAINPARAMSSEEDS_H
#define CHAINPARAMSSEEDS_H

static const unsigned int pnSeed[] =
{
};

static const unsigned int pnTestnetSeed[] =
{
};

#endif
